# DIKWP-MOIRA OS v1.0 快速启动

## 1. 系统定位

DIKWP-MOIRA OS 用于个人本人自愿的价值拓扑、人格动态、道德能动成熟度、条件命运吸引子与主动更新分析。

它**不输出人的价值总分**，不做绝对善恶判决，不宣称未来事件在发生前已经确定。禁止用于就业、信用、保险、执法、刑罚、教育录取、福利资格、政治忠诚或未经同意的真实人物心理画像。

交付包中的示例全部为合成数据，不对应段玉聪或任何真实个人。

## 2. 运行参考内核

在系统包根目录执行：

```bash
python runtime/moira_runtime.py --demo --out examples/demo_output.json
```

使用自己的**自愿、去标识、本地** JSON 输入：

```bash
python runtime/moira_runtime.py \
  --input examples/demo_profile.json \
  --out examples/my_local_report.json
```

## 3. 运行自动测试

```bash
python runtime/test_moira_runtime.py
```

参考交付通过 11 项自动测试，包括：确定性重放、人的价值总分永久为空、F5 仅用于已实际化结果、行动卡 Kill 条件、用途禁区以及 JSON Schema 验证。

## 4. 打开离线驾驶舱

双击或用浏览器打开：

```text
prototype/index.html
```

驾驶舱不联网、不上传数据、不依赖模型 API 或数据库。页面使用合成原型，可调节资源、适应、恢复、价值一致与权力自律等变量，查看命运吸引子、F0—F4 条件命运带和主动更新动作。

## 5. 核心文件

| 路径 | 用途 |
|---|---|
| `docs/*.docx` | 2 万中文字以上的中文最终技术总规范 |
| `runtime/moira_runtime.py` | 确定性 Python 参考内核 |
| `runtime/test_moira_runtime.py` | 自动测试 |
| `prototype/index.html` | 离线交互驾驶舱 |
| `schemas/*.json` | 输入、事件、价值、道德、命运、更新和报告 Schema |
| `config/default_model.json` | 默认证据权重、命运带、道德带与禁用场景 |
| `examples/demo_profile.json` | 合成输入 |
| `examples/demo_output.json` | 确定性参考输出 |
| `assets/*.png` | 总体架构、三账本和条件命运锥 |
| `VALIDATION_REPORT.json` | 交付质检记录 |
| `MANIFEST.sha256` | 文件完整性校验 |

## 6. 最小真实研究流程

真实个人研究不得直接运行一次即下结论。最低流程为：

1. 签署用途与同意合同；
2. 运行 30 日证据协议，覆盖至少两个角色和一次恢复周期；
3. 分离自述、行为、后果与外部实际化；
4. 保存并列解释和残余未知；
5. 对 F3/F4 结论运行反事实干预和独立复核；
6. 由本人决定哪些内容可保留或发布；
7. 90 日失效并重新评估。

## 7. 关键解释

- `M0—M7`：情境和领域中的道德能动成熟度，不是人的内在价值。
- `F0—F4`：未来的开放、倾向、吸引子、锁定和条件近必然。
- `F5`：只表示结果已经在外部世界发生。
- `Residual Ledger`：可能推翻当前结论的未知、异议和模型错误。
- `Kill Condition`：出现特定风险后必须停止行动、评估或发布的条件。
