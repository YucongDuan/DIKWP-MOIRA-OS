#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import copy
import dataclasses
import json
import sys
import unittest
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE / "runtime"))

from moira_runtime import (  # noqa: E402
    DESTINY_BANDS,
    MoiraSystem,
    demo_profile,
    run_demo,
    sha256_json,
)


class MoiraRuntimeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.report = run_demo()

    def test_report_is_deterministic(self):
        r2 = run_demo()
        self.assertEqual(self.report["reproducibility"]["report_hash"], r2["reproducibility"]["report_hash"])

    def test_no_human_worth_score(self):
        status = self.report["epistemic_status"]
        self.assertIsNone(status["human_worth_score"])
        self.assertIsNone(status["absolute_moral_rank"])
        self.assertIsNone(status["unconditional_fate_claim"])

    def test_declared_revealed_gap_is_detected(self):
        gaps = dict(self.report["value_topology"]["largest_gaps"])
        self.assertGreater(gaps.get("生命与健康", 0), 0.4)

    def test_moral_profile_is_domain_specific(self):
        moral = self.report["moral_agency_lattice"]
        self.assertEqual(len(moral["domain_levels"]), 10)
        self.assertIn("不衡量人的内在价值", moral["interpretation"])

    def test_destiny_band_is_valid(self):
        band = self.report["destiny_dynamics"]["destiny_band"]
        self.assertIn(band, DESTINY_BANDS)
        self.assertNotEqual(band, "F5")

    def test_f5_requires_actualization(self):
        profile = demo_profile()
        profile.actualized_outcome = "已完成角色退出并进入新组织"
        report = MoiraSystem().assess(profile)
        self.assertEqual(report["destiny_dynamics"]["destiny_band"], "F5")

    def test_update_actions_have_kill_conditions(self):
        update = self.report["active_update"]["actions_by_horizon"]
        items = [item for rows in update.values() for item in rows]
        self.assertGreaterEqual(len(items), 3)
        self.assertTrue(all(item.get("kill_condition") for item in items))

    def test_residual_ledger_contains_fate_and_moral_risks(self):
        ids = {item["id"] for item in self.report["residual_ledger"]}
        self.assertIn("R-MORAL", ids)
        self.assertIn("R-FATE", ids)

    def test_input_hash_matches_profile(self):
        profile = demo_profile()
        self.assertEqual(self.report["reproducibility"]["input_hash"], sha256_json(dataclasses.asdict(profile)))

    def test_profile_forbidden_scope_is_present(self):
        profile = demo_profile()
        forbidden = set(profile.purpose_contract["forbidden_scope"])
        self.assertIn("就业筛选", forbidden)
        self.assertIn("绝对命运宣告", forbidden)


class SchemaTests(unittest.TestCase):
    def test_json_schemas_validate_examples(self):
        import jsonschema
        from referencing import Registry, Resource

        schemas = {}
        for path in (BASE / "schemas").glob("*.schema.json"):
            schema = json.loads(path.read_text(encoding="utf-8"))
            schemas[schema["$id"]] = schema

        registry = Registry()
        for uri, schema in schemas.items():
            registry = registry.with_resource(uri, Resource.from_contents(schema))

        profile = json.loads((BASE / "examples" / "demo_profile.json").read_text(encoding="utf-8"))
        report = json.loads((BASE / "examples" / "demo_output.json").read_text(encoding="utf-8"))

        jsonschema.Draft202012Validator(
            schemas["https://dikwp.example/schemas/moira/individual_profile.schema.json"],
            registry=registry,
        ).validate(profile)
        jsonschema.Draft202012Validator(
            schemas["https://dikwp.example/schemas/moira/assessment_report.schema.json"],
            registry=registry,
        ).validate(report)


if __name__ == "__main__":
    unittest.main(verbosity=2)
