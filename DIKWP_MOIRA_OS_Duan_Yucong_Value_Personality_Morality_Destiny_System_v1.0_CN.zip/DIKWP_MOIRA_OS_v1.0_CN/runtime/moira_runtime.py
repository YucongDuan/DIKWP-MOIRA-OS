#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""DIKWP-MOIRA OS reference runtime.

A local-first, deterministic reference implementation for modelling:
- value topology (declared vs revealed values),
- dynamic personality fields,
- domain-specific moral agency maturity,
- conditional destiny attractors and intervention windows,
- active update contracts.

This runtime is intentionally NOT a human-worth classifier. It must not be used for
employment, credit, insurance, policing, education admission, welfare eligibility,
or any punitive third-party decision.
"""
from __future__ import annotations

import argparse
import dataclasses
import datetime as dt
import hashlib
import json
import math
import statistics
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, MutableMapping, Optional, Sequence, Tuple

VERSION = "1.0.0"
MODEL_ID = "DIKWP-MOIRA-REF-CN-1.0"

VALUE_DIMENSIONS: Tuple[str, ...] = (
    "生命与健康", "自主与自由", "真相与认知诚实", "关怀与减害", "公平与正义",
    "忠诚与归属", "秩序与责任", "成就与卓越", "创造与探索", "地位与认可",
    "安全与稳定", "愉悦与体验", "意义与超越", "代际责任", "文明公共贡献",
)

PERSONALITY_DIMENSIONS: Tuple[str, ...] = (
    "开放探索", "尽责执行", "社交联结", "共情关怀", "支配与影响",
    "威胁反应", "认知灵活", "自我一致", "元认知", "恢复能力",
    "延迟满足", "权力自律",
)

MORAL_DOMAINS: Tuple[str, ...] = (
    "减害与关怀", "公平与互惠", "诚实与证据", "责任与可追责", "权力与边界",
    "自主与同意", "忠诚与普遍原则", "代际与生态责任", "修复与宽恕", "认识谦逊",
)

RESOURCE_DIMENSIONS: Tuple[str, ...] = (
    "健康", "能量", "时间主权", "经济跑道", "可迁移技能", "可信关系",
    "制度接口", "信息质量", "学习速度", "心理恢复", "身份可塑性", "公共信誉",
)

MORAL_LEVELS: Dict[int, str] = {
    0: "冲动捕获：行为主要由即时欲望、恐惧或权力驱动",
    1: "惩罚规避：主要在外部惩罚存在时守规",
    2: "交换机会：以互惠和个人收益为主要边界",
    3: "角色合规：能履行角色规范，但容易受群体与权威俘获",
    4: "原则一致：能跨情境维持可说明、可复核的原则",
    5: "多元责任：能处理价值冲突、弱者视角和长期后果",
    6: "再生治理：主动修复损害、建设制度并扩大他人选项",
    7: "文明尺度道德能动：在权力、代际与系统风险中保持可追责的公共原则",
}

DESTINY_BANDS: Dict[str, str] = {
    "F0": "开放态：证据不足，未来分支高度开放",
    "F1": "倾向态：出现方向性信号，但可轻易改变",
    "F2": "吸引子态：多种反馈将个体推向同一类路径",
    "F3": "锁定态：退出成本高，需重大资源或关系重构",
    "F4": "条件近必然态：在明确条件集合内，多数可行干预均不能改变结果",
    "F5": "已实际化态：结果已发生并进入只追加事实账本",
}


def clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(value)))


def rounded(value: float, digits: int = 4) -> float:
    return round(float(value), digits)


def stable_json(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_json(data: Any) -> str:
    return hashlib.sha256(stable_json(data).encode("utf-8")).hexdigest()


def mean(values: Iterable[float], default: float = 0.0) -> float:
    vals = list(values)
    return statistics.fmean(vals) if vals else default


def weighted_mean(pairs: Iterable[Tuple[float, float]], default: float = 0.0) -> float:
    pairs = [(float(v), max(0.0, float(w))) for v, w in pairs]
    denom = sum(w for _, w in pairs)
    return sum(v * w for v, w in pairs) / denom if denom > 0 else default


def normalize_scores(scores: Mapping[str, float]) -> Dict[str, float]:
    positives = {k: max(0.0, float(v)) for k, v in scores.items()}
    total = sum(positives.values())
    if total <= 0:
        n = len(positives) or 1
        return {k: 1.0 / n for k in positives}
    return {k: v / total for k, v in positives.items()}


@dataclass
class EvidenceEvent:
    event_id: str
    timestamp: str
    context: str
    declared_intent: str
    action: str
    outcome: str
    value_impacts: Dict[str, float] = field(default_factory=dict)  # -1..1
    personality_signals: Dict[str, float] = field(default_factory=dict)  # 0..1
    moral_signals: Dict[str, float] = field(default_factory=dict)  # 0..1
    cost_to_self: float = 0.0
    benefit_to_self: float = 0.0
    benefit_to_others: float = 0.0
    harm_to_others: float = 0.0
    evidence_quality: float = 0.5
    external_verification: float = 0.0
    responsibility_taken: float = 0.5
    repair_attempted: float = 0.0
    consent_respected: float = 0.5
    truthfulness: float = 0.5
    irreversible: bool = False
    notes: str = ""

    def weight(self) -> float:
        cost_bearing = 0.25 + 0.75 * clamp(self.cost_to_self)
        verification = 0.5 + 0.5 * clamp(self.external_verification)
        return clamp(self.evidence_quality) * cost_bearing * verification


@dataclass
class IndividualProfile:
    profile_id: str
    display_name: str
    assessment_purpose: str
    consent_scope: str
    declared_values: Dict[str, float]
    personality_baseline: Dict[str, float]
    resources: Dict[str, float]
    structural_constraints: Dict[str, float]
    environment: Dict[str, float]
    purpose_contract: Dict[str, Any]
    events: List[EvidenceEvent]
    actualized_outcome: Optional[str] = None
    assessment_date: str = field(default_factory=lambda: dt.date.today().isoformat())


class ValueTopologyEngine:
    def evaluate(self, profile: IndividualProfile) -> Dict[str, Any]:
        declared = {d: clamp(profile.declared_values.get(d, 0.5)) for d in VALUE_DIMENSIONS}
        event_pairs: Dict[str, List[Tuple[float, float]]] = {d: [] for d in VALUE_DIMENSIONS}
        for event in profile.events:
            w = event.weight()
            for d in VALUE_DIMENSIONS:
                if d in event.value_impacts:
                    # map -1..1 alignment to 0..1
                    event_pairs[d].append(((clamp(event.value_impacts[d], -1, 1) + 1) / 2, w))
        revealed = {
            d: weighted_mean(event_pairs[d], default=declared[d])
            for d in VALUE_DIMENSIONS
        }
        gaps = {d: abs(declared[d] - revealed[d]) for d in VALUE_DIMENSIONS}
        coherence = 1.0 - mean(gaps.values(), 0.0)
        high_gap = sorted(gaps.items(), key=lambda kv: kv[1], reverse=True)[:5]
        top_declared = sorted(declared.items(), key=lambda kv: kv[1], reverse=True)[:5]
        top_revealed = sorted(revealed.items(), key=lambda kv: kv[1], reverse=True)[:5]

        # Sacred-value integrity: how often high-declared values survive personal cost.
        sacred = [d for d, score in declared.items() if score >= 0.75]
        sacred_integrities = []
        for d in sacred:
            costly = [
                ((clamp(e.value_impacts[d], -1, 1) + 1) / 2, e.weight())
                for e in profile.events
                if d in e.value_impacts and e.cost_to_self >= 0.35
            ]
            if costly:
                sacred_integrities.append(weighted_mean(costly))
        sacred_integrity = mean(sacred_integrities, default=coherence)

        shadow = {}
        for d in VALUE_DIMENSIONS:
            if declared[d] >= 0.65 and revealed[d] <= 0.4:
                shadow[d] = "宣称高、行动低：可能存在形象管理、自我误认或情境性背离"
            elif declared[d] <= 0.4 and revealed[d] >= 0.65:
                shadow[d] = "宣称低、行动高：可能存在未承认的深层价值或角色义务"

        return {
            "declared": {k: rounded(v) for k, v in declared.items()},
            "revealed": {k: rounded(v) for k, v in revealed.items()},
            "gaps": {k: rounded(v) for k, v in gaps.items()},
            "coherence": rounded(coherence),
            "sacred_value_integrity": rounded(sacred_integrity),
            "top_declared": top_declared,
            "top_revealed": top_revealed,
            "largest_gaps": high_gap,
            "shadow_patterns": shadow,
            "confidence": rounded(clamp(len(profile.events) / 12.0) * mean((e.evidence_quality for e in profile.events), 0.0)),
        }


class PersonalityFieldEngine:
    def evaluate(self, profile: IndividualProfile) -> Dict[str, Any]:
        baseline = {d: clamp(profile.personality_baseline.get(d, 0.5)) for d in PERSONALITY_DIMENSIONS}
        observed: Dict[str, List[Tuple[float, float]]] = {d: [] for d in PERSONALITY_DIMENSIONS}
        for event in profile.events:
            for d, score in event.personality_signals.items():
                if d in observed:
                    observed[d].append((clamp(score), event.weight()))
        state = {
            d: weighted_mean(observed[d], default=baseline[d])
            for d in PERSONALITY_DIMENSIONS
        }
        drift = {d: state[d] - baseline[d] for d in PERSONALITY_DIMENSIONS}
        stability = 1.0 - mean(abs(v) for v in drift.values())
        flexibility = mean([state["认知灵活"], state["元认知"], state["身份可塑性"] if "身份可塑性" in state else 0.5])
        recovery = state["恢复能力"]
        integrity = state["自我一致"]
        power_risk = clamp(state["支配与影响"] * (1.0 - state["权力自律"]))
        threat_capture = clamp(state["威胁反应"] * (1.0 - state["认知灵活"]))
        shadow_mode = []
        if power_risk > 0.55:
            shadow_mode.append("权力扩张型影子：影响力上升时，自我约束不足")
        if threat_capture > 0.55:
            shadow_mode.append("威胁捕获型影子：压力下可能收窄视野并过度防御")
        if recovery < 0.35:
            shadow_mode.append("耗竭固化型影子：恢复不足会把暂时状态误写为人格")
        if integrity < 0.4:
            shadow_mode.append("角色分裂型影子：不同场景中的行为规则缺少统一解释")
        return {
            "baseline": {k: rounded(v) for k, v in baseline.items()},
            "current_state": {k: rounded(v) for k, v in state.items()},
            "drift": {k: rounded(v) for k, v in drift.items()},
            "stability": rounded(stability),
            "adaptability": rounded(clamp((state["认知灵活"] + state["元认知"] + recovery) / 3)),
            "power_capture_risk": rounded(power_risk),
            "threat_capture_risk": rounded(threat_capture),
            "shadow_modes": shadow_mode,
            "confidence": rounded(clamp(len(profile.events) / 10.0) * mean((e.evidence_quality for e in profile.events), 0.0)),
        }


class MoralAgencyLattice:
    def evaluate(self, profile: IndividualProfile) -> Dict[str, Any]:
        domain_scores: Dict[str, float] = {}
        confidence: Dict[str, float] = {}
        evidence_count: Dict[str, int] = {}
        for domain in MORAL_DOMAINS:
            pairs: List[Tuple[float, float]] = []
            for event in profile.events:
                if domain not in event.moral_signals:
                    continue
                base = clamp(event.moral_signals[domain])
                # Outcomes and repair matter more than statements.
                consequence_adjustment = (
                    0.18 * clamp(event.truthfulness)
                    + 0.18 * clamp(event.consent_respected)
                    + 0.18 * clamp(event.responsibility_taken)
                    + 0.14 * clamp(event.repair_attempted)
                    + 0.16 * clamp(event.benefit_to_others)
                    - 0.20 * clamp(event.harm_to_others)
                )
                adjusted = clamp(0.65 * base + consequence_adjustment)
                pairs.append((adjusted, event.weight()))
            score01 = weighted_mean(pairs, default=0.5)
            level = score01 * 7.0
            domain_scores[domain] = level
            confidence[domain] = clamp(sum(w for _, w in pairs) / 3.5)
            evidence_count[domain] = len(pairs)

        # The overall profile is deliberately not a human-worth score.
        minimum_domain = min(domain_scores, key=domain_scores.get)
        maximum_domain = max(domain_scores, key=domain_scores.get)
        median_level = statistics.median(domain_scores.values())
        power_domain = domain_scores["权力与边界"]
        truth_domain = domain_scores["诚实与证据"]
        repair_domain = domain_scores["修复与宽恕"]
        limiting_level = min(power_domain, truth_domain, repair_domain, median_level)
        rounded_level = int(round(clamp(limiting_level / 7.0) * 7))
        return {
            "domain_levels": {k: rounded(v, 3) for k, v in domain_scores.items()},
            "domain_confidence": {k: rounded(v) for k, v in confidence.items()},
            "evidence_count": evidence_count,
            "median_maturity": rounded(median_level, 3),
            "governance_limited_maturity": rounded(limiting_level, 3),
            "reference_band": {"level": rounded_level, "description": MORAL_LEVELS[rounded_level]},
            "strongest_domain": maximum_domain,
            "development_edge": minimum_domain,
            "interpretation": "该结果衡量情境中的道德能动成熟度，不衡量人的内在价值，也不得用于惩罚性排序。",
            "confidence": rounded(mean(confidence.values(), 0.0)),
        }


class DestinyAttractorEngine:
    ATTRACTOR_PROTOTYPES: Dict[str, Dict[str, float]] = {
        "再生型文明建造者": {
            "energy": 0.70, "runway": 0.65, "skills": 0.82, "network": 0.76,
            "institution": 0.62, "adaptability": 0.82, "purpose": 0.88,
            "morality": 0.82, "coherence": 0.80, "recovery": 0.72,
            "power_risk": 0.20, "threat_risk": 0.25,
        },
        "稳定型公共守护者": {
            "energy": 0.62, "runway": 0.72, "skills": 0.62, "network": 0.76,
            "institution": 0.72, "adaptability": 0.60, "purpose": 0.76,
            "morality": 0.84, "coherence": 0.82, "recovery": 0.70,
            "power_risk": 0.18, "threat_risk": 0.30,
        },
        "高影响力—耗竭崩塌": {
            "energy": 0.18, "runway": 0.30, "skills": 0.80, "network": 0.45,
            "institution": 0.46, "adaptability": 0.40, "purpose": 0.84,
            "morality": 0.58, "coherence": 0.56, "recovery": 0.18,
            "power_risk": 0.42, "threat_risk": 0.70,
        },
        "地位捕获—价值漂移": {
            "energy": 0.58, "runway": 0.72, "skills": 0.72, "network": 0.64,
            "institution": 0.82, "adaptability": 0.42, "purpose": 0.44,
            "morality": 0.34, "coherence": 0.28, "recovery": 0.52,
            "power_risk": 0.85, "threat_risk": 0.56,
        },
        "碎片化漂流": {
            "energy": 0.38, "runway": 0.32, "skills": 0.42, "network": 0.34,
            "institution": 0.30, "adaptability": 0.38, "purpose": 0.26,
            "morality": 0.48, "coherence": 0.24, "recovery": 0.34,
            "power_risk": 0.32, "threat_risk": 0.66,
        },
        "修复后跃迁": {
            "energy": 0.50, "runway": 0.48, "skills": 0.68, "network": 0.58,
            "institution": 0.48, "adaptability": 0.88, "purpose": 0.72,
            "morality": 0.74, "coherence": 0.62, "recovery": 0.82,
            "power_risk": 0.24, "threat_risk": 0.34,
        },
    }

    FEATURE_WEIGHTS: Dict[str, float] = {
        "energy": 1.2, "runway": 1.0, "skills": 0.9, "network": 1.0,
        "institution": 0.7, "adaptability": 1.1, "purpose": 1.1,
        "morality": 1.2, "coherence": 1.1, "recovery": 1.0,
        "power_risk": 1.0, "threat_risk": 0.9,
    }

    def _state_vector(
        self,
        profile: IndividualProfile,
        value_result: Mapping[str, Any],
        personality_result: Mapping[str, Any],
        moral_result: Mapping[str, Any],
    ) -> Dict[str, float]:
        r = profile.resources
        p = personality_result["current_state"]
        return {
            "energy": clamp((r.get("能量", 0.5) + r.get("健康", 0.5) + r.get("时间主权", 0.5)) / 3),
            "runway": clamp((r.get("经济跑道", 0.5) + r.get("时间主权", 0.5)) / 2),
            "skills": clamp((r.get("可迁移技能", 0.5) + r.get("学习速度", 0.5)) / 2),
            "network": clamp((r.get("可信关系", 0.5) + r.get("公共信誉", 0.5)) / 2),
            "institution": clamp((r.get("制度接口", 0.5) + r.get("信息质量", 0.5)) / 2),
            "adaptability": clamp(personality_result["adaptability"]),
            "purpose": clamp(profile.purpose_contract.get("purpose_integrity", 0.5)),
            "morality": clamp(moral_result["governance_limited_maturity"] / 7.0),
            "coherence": clamp(value_result["coherence"]),
            "recovery": clamp((p.get("恢复能力", 0.5) + r.get("心理恢复", 0.5)) / 2),
            "power_risk": clamp(personality_result["power_capture_risk"]),
            "threat_risk": clamp(personality_result["threat_capture_risk"]),
        }

    def evaluate(
        self,
        profile: IndividualProfile,
        value_result: Mapping[str, Any],
        personality_result: Mapping[str, Any],
        moral_result: Mapping[str, Any],
    ) -> Dict[str, Any]:
        state = self._state_vector(profile, value_result, personality_result, moral_result)
        raw: Dict[str, float] = {}
        distances: Dict[str, float] = {}
        for name, proto in self.ATTRACTOR_PROTOTYPES.items():
            weighted_distance = 0.0
            total_w = 0.0
            for feature, target in proto.items():
                w = self.FEATURE_WEIGHTS[feature]
                weighted_distance += w * (state[feature] - target) ** 2
                total_w += w
            distance = math.sqrt(weighted_distance / total_w)
            distances[name] = distance
            raw[name] = math.exp(-5.2 * distance)

        # Context modifiers.
        env = profile.environment
        raw["高影响力—耗竭崩塌"] *= 1 + 0.7 * clamp(env.get("加速压力", 0.5))
        raw["地位捕获—价值漂移"] *= 1 + 0.8 * clamp(env.get("权力诱因", 0.4))
        raw["碎片化漂流"] *= 1 + 0.6 * clamp(env.get("信息噪声", 0.5))
        raw["再生型文明建造者"] *= 0.7 + 0.6 * clamp(env.get("协作机会", 0.5))
        raw["稳定型公共守护者"] *= 0.8 + 0.4 * clamp(env.get("制度稳定", 0.5))
        raw["修复后跃迁"] *= 0.7 + 0.7 * state["adaptability"]
        probabilities = normalize_scores(raw)

        constraints = profile.structural_constraints
        lock_in = clamp(mean([
            constraints.get("不可逆承诺", 0.0),
            constraints.get("债务负担", 0.0),
            constraints.get("健康约束", 0.0),
            constraints.get("角色依赖", 0.0),
            constraints.get("法律约束", 0.0),
            constraints.get("关系同质化", 0.0),
            constraints.get("时间窗口逼近", 0.0),
        ]))
        escape_routes = clamp(mean([
            profile.resources.get("经济跑道", 0.5),
            profile.resources.get("可迁移技能", 0.5),
            profile.resources.get("可信关系", 0.5),
            profile.resources.get("健康", 0.5),
            profile.resources.get("时间主权", 0.5),
            profile.resources.get("身份可塑性", 0.5),
            personality_result["adaptability"],
        ]))
        intervention_leverage = clamp(escape_routes * (1.0 - lock_in))
        top_name, top_probability = max(probabilities.items(), key=lambda kv: kv[1])

        if profile.actualized_outcome:
            band = "F5"
        elif top_probability >= 0.55 and lock_in >= 0.75 and intervention_leverage <= 0.18:
            band = "F4"
        elif top_probability >= 0.36 and lock_in >= 0.58:
            band = "F3"
        elif top_probability >= 0.24:
            band = "F2"
        elif top_probability >= 0.18:
            band = "F1"
        else:
            band = "F0"

        critical_junctures: List[Dict[str, str]] = []
        if state["energy"] < 0.42:
            critical_junctures.append({"window": "0—30 天", "issue": "能量与健康", "decision": "削减承诺或进入耗竭锁定"})
        if state["coherence"] < 0.55:
            critical_junctures.append({"window": "30—90 天", "issue": "价值—行动差距", "decision": "公开修正承诺或继续角色分裂"})
        if state["power_risk"] > 0.48:
            critical_junctures.append({"window": "持续", "issue": "权力自律", "decision": "接受外部制衡或进入地位捕获"})
        if escape_routes < 0.45:
            critical_junctures.append({"window": "90—365 天", "issue": "退出路径", "decision": "建立可迁移技能和经济缓冲"})
        if state["adaptability"] > 0.72 and state["recovery"] > 0.55:
            critical_junctures.append({"window": "90—365 天", "issue": "跃迁窗口", "decision": "将修复能力转化为新角色和公共产品"})

        return {
            "state_vector": {k: rounded(v) for k, v in state.items()},
            "attractor_probabilities": {k: rounded(v) for k, v in sorted(probabilities.items(), key=lambda kv: kv[1], reverse=True)},
            "attractor_distances": {k: rounded(v) for k, v in distances.items()},
            "dominant_attractor": top_name,
            "dominant_probability": rounded(top_probability),
            "lock_in": rounded(lock_in),
            "escape_routes": rounded(escape_routes),
            "intervention_leverage": rounded(intervention_leverage),
            "destiny_band": band,
            "destiny_band_description": DESTINY_BANDS[band],
            "conditional_necessity_statement": (
                "只有当列出的结构约束保持不变、可行干预集合被穷尽且结果对干预不敏感时，"
                "F4 才可称为条件近必然；未来事件在发生前永远不得标记为 F5。"
            ),
            "critical_junctures": critical_junctures,
            "actualized_outcome": profile.actualized_outcome,
        }


class ActiveUpdatePlanner:
    def plan(
        self,
        profile: IndividualProfile,
        values: Mapping[str, Any],
        personality: Mapping[str, Any],
        morality: Mapping[str, Any],
        destiny: Mapping[str, Any],
    ) -> Dict[str, Any]:
        actions: List[Dict[str, Any]] = []

        def add(horizon: str, title: str, action: str, metric: str, kill: str, rationale: str) -> None:
            actions.append({
                "horizon": horizon, "title": title, "action": action,
                "success_metric": metric, "kill_condition": kill, "rationale": rationale,
            })

        if profile.resources.get("能量", 0.5) < 0.45 or profile.resources.get("健康", 0.5) < 0.45:
            add("7 日", "能量止损", "冻结一个低价值承诺，建立睡眠、运动、医疗与深度工作四栏账本。",
                "连续 5 天核心能量自评不低于 0.55；至少释放每周 6 小时。",
                "出现持续身体症状、睡眠恶化或医疗风险时，停止自助优化并转专业支持。",
                "没有能量，任何人格、道德和命运判断都会把耗竭误当成真实自我。")
        if values["coherence"] < 0.65:
            gap = values["largest_gaps"][0][0] if values["largest_gaps"] else "核心价值"
            add("30 日", "价值—行动对账", f"围绕“{gap}”选取三个高成本行为证据，删除一个仅用于形象管理的宣称。",
                "宣称—行动平均差距下降至少 20%；形成一份可公开修订的价值声明。",
                "若行动证据不足或涉及他人隐私，停止对外发布，仅保留私有审计。",
                "价值的真实性由承担成本的行动而不是漂亮自述决定。")
        if morality["development_edge"]:
            edge = morality["development_edge"]
            add("30 日", "道德边缘训练", f"针对“{edge}”完成一次真实情境复盘：受影响者、权力差、证据、伤害、责任与修复。",
                "至少获得一名受影响者或独立审阅者反馈，并形成可验证修复动作。",
                "不得用模拟情境替代真实损害修复，也不得强迫受影响者参与。",
                "道德成熟不是回答两难题，而是能在真实代价中承担、修复并接受制衡。")
        if personality["power_capture_risk"] > 0.45:
            add("90 日", "权力外部制衡", "建立三人异议小组；任何高影响决定必须记录反对意见、利益冲突和回滚点。",
                "高影响决定 100% 有异议记录；至少一次因异议而修改或撤销方案。",
                "若异议成员受报复、资源被剥夺或意见被形式化处理，立即暂停该治理机制。",
                "权力越大，自我评价越不可靠，必须用外部结构替代自我美德想象。")
        if destiny["lock_in"] > 0.55 or destiny["escape_routes"] < 0.5:
            add("90 日", "命运弹性工程", "建立一项可迁移技能、一条非同质关系链和三个月最低经济缓冲。",
                "至少两条可行退出路径通过现实小实验验证；单一路径依赖下降。",
                "若新增路径带来不可逆债务、违法风险或健康损害，立即终止。",
                "命运不是口头乐观，而是可被验证的退出路径数量。")
        if destiny["dominant_attractor"] == "高影响力—耗竭崩塌":
            add("7 日", "崩塌前减速", "将旗舰任务从并行多项目收束为一条主航道，其他任务进入地平线银行。",
                "并行高负荷项目数降至 2 个以内；每周至少有一个无输出恢复时段。",
                "若核心利益相关者拒绝削减且健康指标继续下降，启动角色退出预案。",
                "高影响并不抵消生理和组织耗竭，反而放大其外部后果。")
        if destiny["dominant_attractor"] == "地位捕获—价值漂移":
            add("30 日", "地位去魅实验", "选择一个会降低短期声望但提高证据质量或公平性的公开决定。",
                "决策理由、受益者和代价可复核；不以自我牺牲表演替代制度改进。",
                "若该实验伤害无辜者或仅是道德姿态，立即撤回。",
                "检验价值的最强方法，是观察其能否在地位损失时保持。")
        if not actions:
            add("90 日", "保持开放性", "选择一个跨学科、跨阶层或跨文化的小型合作，记录对既有价值和人格模型的反例。",
                "至少发现一个原模型无法解释的新变量，并更新模型版本。",
                "若合作仅扩大同温层或制造表面多样性，停止并重新设计。",
                "稳定不等于完成；开放状态空间需要持续寻找模型之外的反例。")

        horizons = {"7 日": [], "30 日": [], "90 日": [], "365 日": []}
        for item in actions:
            horizons.setdefault(item["horizon"], []).append(item)

        annual = {
            "horizon": "365 日",
            "title": "年度自我版本升级",
            "action": "重新签署 Purpose Contract；公开预测错误、价值漂移、受益与伤害、退出路径和下一年度不做清单。",
            "success_metric": "至少一个旧身份或旧承诺被证据性放弃；至少一个公共产品进入可复现维护。",
            "kill_condition": "不得将年度报告变成宣传材料；发现数据选择性披露时停止发布并独立审计。",
            "rationale": "人格和命运不是静态标签，而是可被历史、关系与自我修正规则共同改写的版本对象。",
        }
        horizons["365 日"].append(annual)
        return {
            "actions_by_horizon": horizons,
            "purpose_contract_update": {
                "current_purpose": profile.purpose_contract.get("primary_purpose", "未定义"),
                "non_tradeable_principles": profile.purpose_contract.get("non_tradeable_principles", []),
                "revocation_authority": profile.purpose_contract.get("revocation_authority", "本人及授权审阅者"),
                "next_review": (dt.date.fromisoformat(profile.assessment_date) + dt.timedelta(days=90)).isoformat(),
            },
        }


class MoiraSystem:
    def __init__(self) -> None:
        self.value_engine = ValueTopologyEngine()
        self.personality_engine = PersonalityFieldEngine()
        self.moral_engine = MoralAgencyLattice()
        self.destiny_engine = DestinyAttractorEngine()
        self.update_planner = ActiveUpdatePlanner()

    def assess(self, profile: IndividualProfile) -> Dict[str, Any]:
        values = self.value_engine.evaluate(profile)
        personality = self.personality_engine.evaluate(profile)
        morality = self.moral_engine.evaluate(profile)
        destiny = self.destiny_engine.evaluate(profile, values, personality, morality)
        update = self.update_planner.plan(profile, values, personality, morality, destiny)
        report = {
            "system": {"name": "DIKWP-MOIRA OS", "version": VERSION, "model_id": MODEL_ID},
            "profile": {
                "profile_id": profile.profile_id,
                "display_name": profile.display_name,
                "assessment_purpose": profile.assessment_purpose,
                "consent_scope": profile.consent_scope,
                "assessment_date": profile.assessment_date,
            },
            "epistemic_status": {
                "human_worth_score": None,
                "absolute_moral_rank": None,
                "unconditional_fate_claim": None,
                "statement": "系统输出是证据条件下的动态模型，不是对人的本体价值、绝对善恶或宇宙命运的判决。",
            },
            "dikwp_r": self._compile_dikwp_r(profile),
            "value_topology": values,
            "personality_field": personality,
            "moral_agency_lattice": morality,
            "destiny_dynamics": destiny,
            "active_update": update,
            "residual_ledger": self._residuals(profile, values, personality, morality, destiny),
        }
        report["reproducibility"] = {
            "input_hash": sha256_json(dataclasses.asdict(profile)),
            "report_hash": sha256_json(report),
            "deterministic": True,
        }
        return report

    def _compile_dikwp_r(self, profile: IndividualProfile) -> Dict[str, Any]:
        return {
            "D_data": {
                "event_count": len(profile.events),
                "resource_dimensions": len(profile.resources),
                "constraint_dimensions": len(profile.structural_constraints),
            },
            "I_information": {
                "contexts": sorted({e.context for e in profile.events}),
                "irreversible_events": [e.event_id for e in profile.events if e.irreversible],
            },
            "K_knowledge": {
                "working_hypotheses": [
                    "宣称价值与承担成本的行动之间的差距可作为自我误认信号",
                    "人格表现受角色、压力和恢复状态影响，不能被单次行为固定",
                    "命运概率取决于资源、约束、反馈回路和可行退出路径",
                ]
            },
            "W_wisdom": {
                "tradeoff_rule": "优先扩大事实、健康、他人自主和未来选项；高影响动作要求更高证据与可撤销性。"
            },
            "P_purpose": profile.purpose_contract,
            "R_residual": {
                "unobserved_private_states": True,
                "observer_effect": True,
                "model_misspecification_possible": True,
            },
        }

    def _residuals(
        self,
        profile: IndividualProfile,
        values: Mapping[str, Any],
        personality: Mapping[str, Any],
        morality: Mapping[str, Any],
        destiny: Mapping[str, Any],
    ) -> List[Dict[str, str]]:
        residuals = [
            {"id": "R-SELFREPORT", "risk": "自我报告可能受形象管理、记忆重构和语言能力影响", "response": "提高成本行为、第三方与结果证据权重"},
            {"id": "R-OBSERVER", "risk": "评估者的文化、利益和权力位置会改变分类", "response": "记录评估目的、异议与替代解释"},
            {"id": "R-FUTURE", "risk": "开放演化会产生模型中不存在的新变量", "response": "保留开放字段与版本更新，不把预测当自然法则"},
            {"id": "R-MORAL", "risk": "道德成熟度可能被误用为人的价值等级", "response": "禁止惩罚性排序，仅用于本人自愿发展和治理结构评估"},
            {"id": "R-FATE", "risk": "概率吸引子可能被包装成宿命并造成自我实现", "response": "展示干预窗口、退出路径和预测影响账本"},
        ]
        if values["confidence"] < 0.45:
            residuals.append({"id": "R-LOWDATA", "risk": "价值证据不足", "response": "不得输出强结论，先收集跨情境证据"})
        if morality["confidence"] < 0.45:
            residuals.append({"id": "R-MORALDATA", "risk": "道德行为证据覆盖不足", "response": "增加真实成本与修复证据，避免两难问卷替代现实"})
        if destiny["destiny_band"] in {"F3", "F4"}:
            residuals.append({"id": "R-LOCKIN", "risk": "锁定判断可能改变个体选择", "response": "在独立复核前不得对外传播，并优先测试反例干预"})
        return residuals


def profile_from_dict(data: Mapping[str, Any]) -> IndividualProfile:
    events = [EvidenceEvent(**event) for event in data.get("events", [])]
    kwargs = dict(data)
    kwargs["events"] = events
    return IndividualProfile(**kwargs)


def demo_profile() -> IndividualProfile:
    def ev(
        eid: str, context: str, declared: str, action: str, outcome: str,
        value_impacts: Dict[str, float], personality: Dict[str, float], moral: Dict[str, float],
        cost: float, benefit_self: float, benefit_others: float, harm: float,
        quality: float, verify: float, responsibility: float, repair: float,
        consent: float, truth: float, irreversible: bool = False,
    ) -> EvidenceEvent:
        return EvidenceEvent(
            event_id=eid, timestamp=f"2026-0{(int(eid[-2:]) % 6) + 1}-15T09:00:00+08:00",
            context=context, declared_intent=declared, action=action, outcome=outcome,
            value_impacts=value_impacts, personality_signals=personality, moral_signals=moral,
            cost_to_self=cost, benefit_to_self=benefit_self, benefit_to_others=benefit_others,
            harm_to_others=harm, evidence_quality=quality, external_verification=verify,
            responsibility_taken=responsibility, repair_attempted=repair,
            consent_respected=consent, truthfulness=truth, irreversible=irreversible,
        )

    events = [
        ev("E01", "研究与公共产品", "推动可复现的人工意识研究", "公开协议、代码和失败记录", "形成可复现资产但投入过载",
           {"真相与认知诚实": 0.9, "创造与探索": 0.9, "文明公共贡献": 0.9, "生命与健康": -0.45},
           {"开放探索": 0.95, "尽责执行": 0.85, "元认知": 0.75, "恢复能力": 0.28, "自我一致": 0.78},
           {"诚实与证据": 0.88, "责任与可追责": 0.82, "代际与生态责任": 0.75},
           0.72, 0.55, 0.82, 0.08, 0.92, 0.85, 0.82, 0.20, 0.90, 0.92),
        ev("E02", "团队冲突", "保护学术质量", "在时间压力下压缩异议讨论", "交付加快但成员信任下降",
           {"成就与卓越": 0.75, "公平与正义": -0.45, "关怀与减害": -0.35, "秩序与责任": 0.45},
           {"支配与影响": 0.78, "威胁反应": 0.68, "认知灵活": 0.42, "权力自律": 0.38, "共情关怀": 0.44},
           {"权力与边界": 0.30, "自主与同意": 0.35, "公平与互惠": 0.38, "责任与可追责": 0.60},
           0.22, 0.68, 0.45, 0.35, 0.84, 0.72, 0.58, 0.15, 0.38, 0.76),
        ev("E03", "公开争议", "维护理论创新", "公开承认一个预测错误并修订文档", "短期声望受损，长期可信度上升",
           {"真相与认知诚实": 0.95, "地位与认可": -0.35, "文明公共贡献": 0.72},
           {"元认知": 0.88, "自我一致": 0.85, "威胁反应": 0.36, "恢复能力": 0.62},
           {"诚实与证据": 0.95, "责任与可追责": 0.88, "认识谦逊": 0.92, "修复与宽恕": 0.72},
           0.55, 0.32, 0.75, 0.05, 0.94, 0.90, 0.92, 0.72, 0.95, 0.96),
        ev("E04", "资源分配", "支持青年研究者", "将部分经费和署名机会转给青年团队", "旗舰项目速度下降，团队能力上升",
           {"公平与正义": 0.82, "关怀与减害": 0.74, "文明公共贡献": 0.84, "地位与认可": -0.22},
           {"共情关怀": 0.78, "权力自律": 0.82, "延迟满足": 0.80, "尽责执行": 0.72},
           {"公平与互惠": 0.88, "权力与边界": 0.86, "代际与生态责任": 0.84, "自主与同意": 0.82},
           0.62, 0.30, 0.88, 0.02, 0.90, 0.82, 0.86, 0.30, 0.92, 0.88),
        ev("E05", "家庭与健康", "保持长期创造力", "连续三月牺牲睡眠以完成多项交付", "出现恢复下降和注意波动",
           {"成就与卓越": 0.88, "创造与探索": 0.75, "生命与健康": -0.82, "关怀与减害": -0.35},
           {"尽责执行": 0.90, "恢复能力": 0.18, "威胁反应": 0.72, "延迟满足": 0.92, "认知灵活": 0.40},
           {"责任与可追责": 0.55, "减害与关怀": 0.38, "认识谦逊": 0.48},
           0.85, 0.70, 0.58, 0.22, 0.88, 0.78, 0.55, 0.10, 0.82, 0.84),
        ev("E06", "合作选择", "建立国际开放网络", "拒绝带排他条款的高额合作，保留开放许可", "资源减少但生态开放",
           {"自主与自由": 0.85, "真相与认知诚实": 0.76, "文明公共贡献": 0.88, "安全与稳定": -0.30},
           {"开放探索": 0.86, "权力自律": 0.82, "自我一致": 0.84, "延迟满足": 0.78},
           {"自主与同意": 0.86, "诚实与证据": 0.82, "权力与边界": 0.84, "代际与生态责任": 0.80},
           0.68, 0.24, 0.78, 0.03, 0.88, 0.76, 0.84, 0.20, 0.92, 0.88),
        ev("E07", "产品失败", "验证新型评估系统", "在失败后保留日志并向用户说明局限", "避免扩大部署并形成失败案例",
           {"真相与认知诚实": 0.90, "秩序与责任": 0.82, "地位与认可": -0.20},
           {"元认知": 0.88, "恢复能力": 0.66, "尽责执行": 0.82, "自我一致": 0.86},
           {"责任与可追责": 0.92, "修复与宽恕": 0.86, "诚实与证据": 0.94, "减害与关怀": 0.82},
           0.45, 0.22, 0.72, 0.04, 0.94, 0.90, 0.94, 0.85, 0.90, 0.95),
        ev("E08", "舆论传播", "扩大理论影响", "采用夸张标题但正文保留限定", "传播扩大，同时引发误读",
           {"地位与认可": 0.70, "文明公共贡献": 0.45, "真相与认知诚实": -0.32},
           {"支配与影响": 0.76, "自我一致": 0.50, "权力自律": 0.48, "社交联结": 0.72},
           {"诚实与证据": 0.48, "责任与可追责": 0.55, "认识谦逊": 0.52},
           0.18, 0.76, 0.50, 0.22, 0.78, 0.70, 0.58, 0.12, 0.82, 0.58),
        ev("E09", "数据伦理", "加速个体评估研究", "拒绝未经同意使用真实个人数据，改用合成样例", "研究速度下降，隐私风险降低",
           {"关怀与减害": 0.88, "公平与正义": 0.82, "真相与认知诚实": 0.78, "成就与卓越": -0.25},
           {"权力自律": 0.88, "共情关怀": 0.82, "延迟满足": 0.80, "尽责执行": 0.74},
           {"自主与同意": 0.96, "权力与边界": 0.92, "减害与关怀": 0.90, "诚实与证据": 0.86},
           0.52, 0.18, 0.82, 0.01, 0.96, 0.88, 0.90, 0.20, 0.98, 0.92),
        ev("E10", "长期方向", "建立文明级公共基础设施", "收束项目并建立版本治理", "短期曝光下降，资产复用提高",
           {"文明公共贡献": 0.92, "代际责任": 0.88, "安全与稳定": 0.65, "地位与认可": -0.18},
           {"尽责执行": 0.84, "认知灵活": 0.76, "元认知": 0.82, "恢复能力": 0.52, "自我一致": 0.82},
           {"代际与生态责任": 0.90, "责任与可追责": 0.86, "认识谦逊": 0.76},
           0.58, 0.35, 0.86, 0.02, 0.92, 0.84, 0.88, 0.25, 0.92, 0.90, irreversible=True),
    ]

    return IndividualProfile(
        profile_id="P-FICTION-001",
        display_name="合成样例：高认知高过载研究者",
        assessment_purpose="个人自愿的研究方向、资源配置与文明贡献更新",
        consent_scope="仅本地个人发展；禁止第三方惩罚性决策和真实人物推断",
        declared_values={
            "生命与健康": 0.72, "自主与自由": 0.82, "真相与认知诚实": 0.92,
            "关怀与减害": 0.78, "公平与正义": 0.82, "忠诚与归属": 0.58,
            "秩序与责任": 0.80, "成就与卓越": 0.90, "创造与探索": 0.96,
            "地位与认可": 0.35, "安全与稳定": 0.52, "愉悦与体验": 0.42,
            "意义与超越": 0.90, "代际责任": 0.88, "文明公共贡献": 0.96,
        },
        personality_baseline={
            "开放探索": 0.92, "尽责执行": 0.82, "社交联结": 0.58, "共情关怀": 0.70,
            "支配与影响": 0.68, "威胁反应": 0.48, "认知灵活": 0.76, "自我一致": 0.72,
            "元认知": 0.82, "恢复能力": 0.46, "延迟满足": 0.86, "权力自律": 0.66,
        },
        resources={
            "健康": 0.48, "能量": 0.36, "时间主权": 0.32, "经济跑道": 0.46,
            "可迁移技能": 0.88, "可信关系": 0.58, "制度接口": 0.44, "信息质量": 0.84,
            "学习速度": 0.88, "心理恢复": 0.42, "身份可塑性": 0.76, "公共信誉": 0.72,
        },
        structural_constraints={
            "不可逆承诺": 0.52, "债务负担": 0.22, "健康约束": 0.44, "角色依赖": 0.68,
            "法律约束": 0.18, "关系同质化": 0.46, "时间窗口逼近": 0.74,
        },
        environment={
            "加速压力": 0.82, "权力诱因": 0.58, "信息噪声": 0.72,
            "协作机会": 0.70, "制度稳定": 0.46,
        },
        purpose_contract={
            "primary_purpose": "把 DIKWP 转化为可引用、可复现、可执行、可持续迭代的文明公共基础设施",
            "purpose_integrity": 0.84,
            "non_tradeable_principles": ["不伪造证据", "不以自主智能转移人类责任", "不以个体评分剥夺权利", "高影响行动可暂停可回滚"],
            "authorized_scope": ["研究", "公开协议", "合成数据演示", "自愿个体更新"],
            "forbidden_scope": ["就业筛选", "信用与保险", "执法与刑罚", "未经同意的人格推断", "绝对命运宣告"],
            "revocation_authority": "本人、数据主体和独立伦理审阅者",
        },
        events=events,
        assessment_date="2026-07-15",
    )


def run_demo(output_path: Optional[Path] = None) -> Dict[str, Any]:
    report = MoiraSystem().assess(demo_profile())
    if output_path:
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="DIKWP-MOIRA OS reference runtime")
    parser.add_argument("--input", type=Path, help="Input profile JSON")
    parser.add_argument("--demo", action="store_true", help="Run bundled fictional demo")
    parser.add_argument("--out", type=Path, help="Write report JSON")
    args = parser.parse_args()

    if args.demo or not args.input:
        report = run_demo(args.out)
    else:
        data = json.loads(args.input.read_text(encoding="utf-8"))
        report = MoiraSystem().assess(profile_from_dict(data))
        if args.out:
            args.out.parent.mkdir(parents=True, exist_ok=True)
            args.out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({
        "profile": report["profile"],
        "dominant_attractor": report["destiny_dynamics"]["dominant_attractor"],
        "destiny_band": report["destiny_dynamics"]["destiny_band"],
        "moral_reference_band": report["moral_agency_lattice"]["reference_band"],
        "report_hash": report["reproducibility"]["report_hash"],
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
